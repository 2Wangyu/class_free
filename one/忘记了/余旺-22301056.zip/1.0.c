/* Name:YU.
* ID:22301056
* Date:22-09-20 17:00
* Description:Separating Digits in an Integere
*/
#include<stdio.h>
int main()
{
	int a, b, c, d, e, f;
	printf("������һ����λ��");
	scanf_s("%d", &f);
	a = f / 10000;
	b = f / 1000 % 10;
	c = f / 100 % 10;
	d = f / 10 % 10;
	e = f / 1 % 10;
	printf("%d    %d    %d    %d    %d", a, b, c, d, e);
	return 0;
}