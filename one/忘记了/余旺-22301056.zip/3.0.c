﻿/* Name:YU.
* ID:22301056
* Date:22-09-20 17:00
* Description:Separating Digits in an Integere
*/
#include<stdio.h>
int main()
{
	int u = 5;
	int a = 4;
	int t = 3;
	int v, s; 
	int t² = 9;
	s= u * t + 1.0 / 2 * a * t²;
	v = u + a * t;
	printf("v=%d\n s=%d",v, s);

	return 0;
}