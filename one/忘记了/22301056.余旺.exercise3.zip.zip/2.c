/*Name:Yu
Date:2022.09.27
Description : change
*/
#include<stdio.h>
#include <math.h>
int main()
{
	int x;
	int y;
	int Distance = sqrt(x * x + y * y);
	scanf_s("%d %d", &x, &y);
   int answer = (int)(Distance + 0.5);
   printf("���յ�sally�ҵ���̾���ͽ��Ϊ%d %d",Distance, answer);


	return 0;
}