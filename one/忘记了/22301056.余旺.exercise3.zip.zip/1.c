/*Name:Yu
Date:2022.09.27
Description : change
*/
#include<stdio.h>
int main()
{
	double paid, check; int change;
	paid = 20.00; check = 17.17;
	/* determine the amount of the change */
	change = (paid - check)*100+0.5 ;
	/* determine the number of dollars in the change */
	printf("%d\n", change);
	int dollars =( change) / 100;
	int a = (change % 100) / 25;
	int b = (change-dollars*100-(a*25)) / 10;
	int c = (change-dollars*100-(a*25)-(b*10)) / 5;
	int e = (change-dollars * 100 -(a*25)-(b*10)-(c*5))/1;
	printf("��Ǯ��һ��Ԫ��25���֣�10���֣�5���֣�1���ֵ������ֱ�Ϊ%d%d%d%d",
		dollars, a, b, c);
	printf("%d\n", e);

		return 0;
}
