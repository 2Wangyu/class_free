#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTcpSocket>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    sql=new MySQL();
    sql->initSQL();

    m_tcpServer=new QTcpServer(this);
    if(!m_tcpServer->listen(QHostAddress::AnyIPv4,6666)){
            qDebug()<<m_tcpServer->errorString();
            close();
        }
        connect(m_tcpServer,&QTcpServer::newConnection,this,&MainWindow::onNewConnect);
        connect(m_tcpServer,&QTcpServer::newConnection,this,&MainWindow::onSendBackMsg);
    }
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onNewConnect()
{
    //当前连接的客户端
    m_tcpSocket=m_tcpServer->nextPendingConnection();

    //socket有数据时会发送readyRead信号
    connect(m_tcpSocket,&QTcpSocket::readyRead,
            this,&MainWindow::onReadMsg);

    //断开连接
    connect(m_tcpSocket,&QTcpSocket::disconnected,
           m_tcpSocket,&QTcpSocket::deleteLater);
}

void MainWindow::onSendBackMsg()
{
    QString str="你好，客户端！";
    //m_tcpSocket->write(str.toUtf8());
    ui->label->setText("反馈数据成功！");
}

void MainWindow::onReadMsg()
{
    //服务端将客户端发来的数据显示到标签上
    QByteArray bt=m_tcpSocket->readAll();
    ui->lineEdit->setText(bt);
    QString string=ui->lineEdit->text();
    QStringList strList = string.split(" ");
    User *user=new User();

    //服务器端注册功能
    if(strList[0]=="-R"){
        user->setUserName(strList[1]);
        user->setUserAccount(strList[2]);
        user->setUserPassword(strList[3]);

        if(!sql->IfUserExit(*user)){
            sql->insertSQL(*user);
            QString str="-R f";
            m_tcpSocket->write(str.toUtf8());
        }
        else{
            QString str="-R t";
            m_tcpSocket->write(str.toUtf8());
        }
    }

    //服务器端登陆功能
    else if(strList[0]=="-L"){
        user->setUserAccount(strList[1]);
        user->setUserPassword(strList[2]);
        if(sql->findUser(*user)){
            QString str="-L t";
            m_tcpSocket->write(str.toUtf8());
        }
        else{
            QString str="-L f";
            m_tcpSocket->write(str.toUtf8());
        }
    }
}


void MainWindow::on_pushButton_clicked()
{
    sql->findSQL();
}
