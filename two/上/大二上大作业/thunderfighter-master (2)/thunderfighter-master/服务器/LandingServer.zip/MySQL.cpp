#include "MySQL.h"

void MySQL::initSQL()
{
    // 数据库连接需要设置的信息
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("parking.db");

    if (!db.open()) {
        qDebug() << "无法打开数据库";
    }
    // 创建表
    QSqlQuery query(db);
    //query.exec("DROP TABLE IF EXISTS users");
    query.exec("CREATE TABLE IF NOT EXISTS users ("
               "user_account TEXT PRIMARY KEY, "
               "user_name TEXT, "
               "user_password TEXT)"
               );
    if (!query.isActive()) {
        qDebug() << "无法创建表";
    }

}

void MySQL::insertSQL(User &user)
{
    qDebug() << "insert";
    QSqlQuery query(db);
    query.prepare("INSERT INTO users (user_account, user_name, user_password) "
                  "VALUES (:user_account, :user_name, :user_password)");
    query.bindValue(":user_account", user.getUserAccount());
    query.bindValue(":user_name", user.getUserName());
    query.bindValue(":user_password", user.getUserPassword());
    if (!query.exec()) {
        qDebug() << "无法插入数据";
    }
}

void MySQL::findSQL()// 查询数据
{
    qDebug() << "find";
    QSqlQuery query(db);
    query.exec("SELECT * FROM users");
    while (query.next()) {
        QString user_account = query.value("user_account").toString();
        QString user_password = query.value("user_password").toString();
        QString user_name =query.value("user_name").toString();
        qDebug() <<user_name<<user_account<<user_password;

        //int parkingSpot = query.value("parking_spot").toInt();
        //double fee = query.value("fee").toDouble();
        //qDebug() << carPlate << parkingTime << parkingSpot << fee;
    }
}

//查找数据库中是否存在该用户
bool MySQL::findUser(User &user){
    QSqlQuery query(db);
    query.exec("SELECT * FROM users");


    while(query.next()){
        QString user_account = query.value("user_account").toString();
        QString user_password = query.value("user_password").toString();
        if(user_account==user.getUserAccount()&&user_password==user.getUserPassword()){
            return true;
        }
    }
    return false;
}

    /*
    // 创建一个QPieSlice对象，并设置标签和百分比
    foreach (QPieSlice *slice, series->slices()) {
        QString label = slice->label();
        double percentage = slice->percentage() * 100;
        slice->setLabel(QString("%1: %2%").arg(label).arg(percentage, 0, 'f', 1));
    }
    */

bool MySQL::IfUserExit(User &user){
    QSqlQuery query(db);
    query.exec("SELECT * FROM users");

    while(query.next()){
        QString user_account = query.value("user_account").toString();
        QString user_name = query.value("user_name").toString();
        if(user_account==user.getUserAccount()||user_name==user.getUserName()){
            return true;
        }
    }
    return false;
}


QSqlDatabase MySQL::getDb()
{
    return db;
}
