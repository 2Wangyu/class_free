#ifndef MYSQL_H
#define MYSQL_H
#include "user.h"
#include <QtSql>

class MySQL{
public:
    void initSQL();//初始化数据库
    void insertSQL(User &user);//插入数据
    void findSQL();//查找数据
    bool findUser(User &user);
    bool IfUserExit(User &user);
    QSqlDatabase getDb();//获得数据库指针
private:
    QSqlDatabase db;//数据库指针
};

#endif // MYSQL_H
