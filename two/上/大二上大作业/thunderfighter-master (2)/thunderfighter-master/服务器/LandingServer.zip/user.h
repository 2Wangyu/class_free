#ifndef USER_H
#define USER_H
#include <QString>

class User
{
public:
    User();
    ~User();

    int getUserScore() const;
    void setUserScore(int value);

    QString getUserAccount() const;
    void setUserAccount(const QString &value);

    QString getUserPassword() const;
    void setUserPassword(const QString &value);

    QString getUserName() const;
    void setUserName(const QString &value);

    int getPlaneBlood() const;
    void setPlaneBlood(int value);

    int getPlaneAttack() const;
    void setPlaneAttack(int value);

    QString getPlanePath() const;
    void setPlanePath(const QString &value);

private:
    QString userName;
    QString userPassword;
    QString userAccount;
    QString planePath;
    int planeAttack;
    int planeBlood;
    int score;
};

#endif // USER_H
