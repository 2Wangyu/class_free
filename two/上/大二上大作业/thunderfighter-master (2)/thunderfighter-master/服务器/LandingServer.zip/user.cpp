#include "user.h"

User::User(){ 
}

int User::getUserScore() const
{
    return score;
}

void User::setUserScore(int value)
{
    score = value;
}

QString User::getUserAccount() const
{
    return userAccount;
}

void User::setUserAccount(const QString &value)
{
    userAccount = value;
}

QString User::getUserPassword() const
{
    return userPassword;
}

void User::setUserPassword(const QString &value)
{
    userPassword = value;
}

QString User::getUserName() const
{
    return userName;
}

void User::setUserName(const QString &value)
{
    userName = value;
}

int User::getPlaneBlood() const
{
    return planeBlood;
}

void User::setPlaneBlood(int value)
{
    planeBlood = value;
}

int User::getPlaneAttack() const
{
    return planeAttack;
}

void User::setPlaneAttack(int value)
{
    planeAttack = value;
}

QString User::getPlanePath() const
{
    return planePath;
}

void User::setPlanePath(const QString &value)
{
    planePath = value;
}
